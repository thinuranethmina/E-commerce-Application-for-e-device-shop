<?php
    $hour = date('H');
    $greeting = '';

    if ($hour < 12) {
        $greeting = 'Good Morning!';
    } elseif ($hour < 18) {
        $greeting = 'Good Afternoon!';
    } else {
        $greeting = 'Good Evening!';
    }
?>
<h3 class="greeting-text">
    <?php echo e($greeting); ?>

</h3>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/components/greeting.blade.php ENDPATH**/ ?>