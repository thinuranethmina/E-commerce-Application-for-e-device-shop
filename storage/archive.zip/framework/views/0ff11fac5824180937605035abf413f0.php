<a href="<?php echo e($banner->url); ?>">
    <div class="card">
        <img src="<?php echo e(asset($banner->image)); ?>" alt="<?php echo e($banner->title); ?>">
    </div>
</a>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/components/offer-card.blade.php ENDPATH**/ ?>