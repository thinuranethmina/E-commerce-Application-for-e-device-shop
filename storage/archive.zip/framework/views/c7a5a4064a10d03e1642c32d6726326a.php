<div class="image-chooser">
    <label for="<?php echo e($name); ?>">
        <div class="preview-image <?php echo e($type ?? ''); ?>" style="background-color: <?php echo e($bgColor ?? 'white'); ?>">
            <img id="<?php echo e($name); ?>Preview" class="image <?php echo e($cover ? 'cover' : 'contain'); ?>"
                src="<?php echo e($src ?? asset('assets/global/images/default.png')); ?>"
                style="width: <?php echo e($width ?? '100%'); ?>; height: <?php echo e($height ?? '100%'); ?>; max-height: <?php echo e($maxHeight ?? '200px'); ?>;">
            <div class="image-overlay"></div>
        </div>
    </label>
</div>

<input type="file" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" class="form-control d-none"
    onchange="previewImage(this, '<?php echo e($name); ?>Preview');">
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/components/image-chooser.blade.php ENDPATH**/ ?>