<div class="col-12">
    <div class="page-header">
        <h1 class="page-title my-auto"><?php echo $__env->yieldContent('page'); ?></h1>
        <div>
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('admin.dashboard')); ?>">Home</a>
                </li>
                <?php $__currentLoopData = Request::segments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($segment !== 'admin'): ?>
                        <?php
                            $breadcrumb = ucfirst(str_replace('-', ' ', $segment));
                        ?>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($breadcrumb); ?></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </div>
    </div>
</div>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/components/breadcrumb.blade.php ENDPATH**/ ?>