<?php $__env->startSection('page', 'Edit Order'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.components.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row top-row">

        <div class="col-12">
            <form action="<?php echo e(route('admin.orders.update', $item->id)); ?>" method="POST" enctype="multipart/form-data"
                class="ajaxForm">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-xl-8">
                        <div class="card">
                            <div class="card-body">
                                <div class="col-lg-12">

                                    <div class="d-flex justify-content-between gap-2 flex-wrap">
                                        <h4 class="mb-3 header-title">Order Details</h4>

                                        <div class="d-flex gap-2">
                                            <p>
                                                Payment Status:
                                                <span class="badge bg-success">
                                                    <?php echo e($item->payment->payment_status); ?></span>
                                            </p>
                                            <p>
                                                Deliver Status:
                                                <span class="badge bg-warning">
                                                    <?php echo e($item->deliver_status); ?></span>
                                            </p>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-12">
                                            <div class="table-responsive mb-3 overflow-y-hidden">
                                                <table class="table table-bordered table-centered mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th style="min-width: 30px;">#</th>
                                                            <th style="min-width: 200px;">Product</th>
                                                            <th style="min-width: 200px;">Qty</th>
                                                            <th style="min-width: 30px;">Price</th>
                                                            <th style="min-width: 100px;">Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $item->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($index + 1); ?></td>
                                                                <td><?php echo e($order_item->productVariation->product->name); ?>

                                                                    <?php if($order_item->productVariation->values->count() > 0): ?>
                                                                        (<?php $__currentLoopData = $order_item->productVariation->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php echo e($type->variationValue->variable); ?>

                                                                            <?php if(!$loop->last): ?>
                                                                                |
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>)
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td><?php echo e($order_item->qty); ?></td>
                                                                <td><?php echo e(number_format($order_item->price, 2)); ?></td>
                                                                <td style="text-align: right !important;">
                                                                    <?php echo e(number_format($order_item->price * $order_item->qty, 2)); ?>

                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td colspan="3" class="text-right">Sub Total</td>
                                                            <td style="text-align: right !important;">LKR</td>
                                                            <td style="text-align: right !important;">
                                                                <?php echo e(number_format($item->sub_total, 2)); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="3" class="text-right">Delivery Charge</td>
                                                            <td style="text-align: right !important;">LKR</td>
                                                            <td style="text-align: right !important;">
                                                                <?php echo e(number_format($item->delivery_fee, 2)); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="3" class="text-right">Total</td>
                                                            <td style="text-align: right !important;">LKR</td>
                                                            <td style="text-align: right !important;">
                                                                <?php echo e(number_format($item->total, 2)); ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                        <div class="col-12 col-xl-6">
                                            <div class="form-group">
                                                <label class="form-label" for="site_name">Order ID</label>
                                                <input type="text" name="site_name" id="site_name" class="form-control"
                                                    value="<?php echo e($item->ref); ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="col-12 col-xl-6">
                                            <div class="form-group">
                                                <label class="form-label" for="site_name">Payment Method</label>
                                                <input type="text" name="site_name" id="site_name" class="form-control"
                                                    value="<?php echo e($item->payment->payment_method); ?>" readonly>
                                            </div>
                                        </div>

                                        <?php if($item->payment->payment_status == 'Paid'): ?>
                                            <div class="col-12 col-xl-6">
                                                <div class="form-group">
                                                    <label class="form-label"
                                                        for="date"><?php echo e($item->payment->payment_method == 'Card' ? 'Card' : 'Admin Approved At'); ?></label>
                                                    <input type="text" name="date" id="date" class="form-control"
                                                        value="<?php echo e($item->payment->updated_at->format('Y-m-d h:i A')); ?>"
                                                        readonly>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                        <div class="col-12">
                                            <div class="form-group">
                                                <label class="form-label" for="note">Note</label>
                                                <textarea class="form-control" name="note" rows="5"><?php echo e($item->note); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="d-flex justify-content-end">
                                            <button type="submit" class="btn btn-primary">Save
                                                Changes</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="col-lg-12">
                                    <div class="form-group d-flex gap-2">
                                        <div class="btn-group w-100">
                                            <button class="btn btn-dark btn-lg dropdown-toggle" type="button"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                Payment Status
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <input type="radio" id="Pending" value="Pending"
                                                        name="payment_status" class="d-none"
                                                        <?php echo e($item->payment->payment_status == 'Pending' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Pending">
                                                        Pending
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="Paid" value="Paid"
                                                        name="payment_status" class="d-none"
                                                        <?php echo e($item->payment->payment_status == 'Paid' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Paid">
                                                        Paid
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="Failed" value="Failed"
                                                        name="payment_status" class="d-none"
                                                        <?php echo e($item->payment->payment_status == 'Failed' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Failed">
                                                        Failed
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="Refunded" value="Refunded"
                                                        name="payment_status" class="d-none"
                                                        <?php echo e($item->payment->payment_status == 'Refunded' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Refunded">
                                                        Refunded
                                                    </label>
                                                </li>
                                            </ul>
                                        </div>

                                        <div class="btn-group w-100">
                                            <button class="btn btn-dark btn-lg dropdown-toggle" type="button"
                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                Delivery Status
                                            </button>
                                            <ul class="dropdown-menu">
                                                <li>
                                                    <input type="radio" id="Pending" value="Pending"
                                                        name="delivery_status" class="d-none"
                                                        <?php echo e($item->deliver_status == 'Pending' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Pending">
                                                        Pending
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="Confirmed" value="Confirmed"
                                                        name="delivery_status" class="d-none"
                                                        <?php echo e($item->deliver_status == 'Confirmed' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Confirmed">
                                                        Approved
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="Delivered" value="Delivered"
                                                        name="delivery_status" class="d-none"
                                                        <?php echo e($item->deliver_status == 'Delivered' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Delivered">
                                                        Delivered
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="Cancelled" value="Cancelled"
                                                        name="delivery_status" class="d-none"
                                                        <?php echo e($item->deliver_status == 'Cancelled' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Cancelled">
                                                        Cancelled
                                                    </label>
                                                </li>
                                                <li>
                                                    <input type="radio" id="Returned" value="Returned"
                                                        name="delivery_status" class="d-none"
                                                        <?php echo e($item->deliver_status == 'Returned' ? 'checked' : ''); ?>>
                                                    <label class="py-2 px-3 w-100" for="Returned">
                                                        Returned
                                                    </label>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                    <h4 class="mb-3 header-title">Customer Details</h4>

                                    <div class="form-group">
                                        <label class="form-label" for="customer_first_name">Customer First name</label>
                                        <input type="text" name="customer_first_name" id="customer_first_name"
                                            class="form-control" value="<?php echo e($item->customer_first_name); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="customer_last_name">Customer Last name</label>
                                        <input type="text" name="customer_last_name" id="customer_last_name"
                                            class="form-control" value="<?php echo e($item->customer_last_name); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="phone">Phone</label>
                                        <input type="text" name="phone" id="phone" class="form-control"
                                            value="<?php echo e($item->phone); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="email">Email</label>
                                        <input type="text" name="email" id="email" class="form-control"
                                            value="<?php echo e($item->email); ?>">
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label" for="address">Address</label>
                                        <textarea class="form-control" id="address" name="address" rows="5"><?php echo e($item->address); ?></textarea>
                                    </div>

                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label" for="site_name">Payment Response</label>
                                            <textarea class="form-control" rows="8" readonly><?php echo e($item->payment->response); ?></textarea>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </div>

    <script>
        document.querySelectorAll('input[type="radio"]').forEach((radio) => {
            radio.addEventListener('change', () => {
                document.querySelector('.ajaxForm').querySelector('[type="submit"]').click();
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/pages/orders/edit.blade.php ENDPATH**/ ?>