<?php $__currentLoopData = $item->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($value->id); ?>"><?php echo e($value->variable); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/pages/variation/select-values.blade.php ENDPATH**/ ?>