<div class="row purchase-success-modal">
    <div class="col-12 p-3 px-lg-5 my-lg-4">
        <div class="text-center">
            <svg id="checkbox" xmlns="http://www.w3.org/2000/svg" width="99.012" height="99.012"
                viewBox="0 0 99.012 99.012">
                <path id="Path_341" data-name="Path 341"
                    d="M78.384,0H20.628A20.652,20.652,0,0,0,0,20.628V78.384A20.652,20.652,0,0,0,20.628,99.012H78.384A20.652,20.652,0,0,0,99.012,78.384V20.628A20.652,20.652,0,0,0,78.384,0ZM82.51,33.33,44.332,71.507a8.251,8.251,0,0,1-11.669,0l0,0L16.5,55.352a4.134,4.134,0,0,1,5.846-5.846L38.5,65.661,76.684,27.484A4.126,4.126,0,0,1,82.51,33.33Z"
                    fill="#0db5ab" />
            </svg>
            <h2 class="title">Thank You For Your Purchase! </h2>
            <p class="text-center description">
                Dear <?php echo e($order->customer_first_name . ' ' . $order->customer_last_name); ?>, Your Order Has Been
                Successfully
                Placed! <br>
                <strong class="order-number">Order Number: #<?php echo e($order->ref); ?> &nbsp; Date:
                    <?php echo e($order->created_at->format('Y-m-d')); ?></strong>
                <br><br>
                A Confirmation Email Has Been Sent To Your Inbox. Please Check It For The Details Of
                Your Order.
            </p>
            <a href="<?php echo e(route('home')); ?>" type="button" class="btn secondary-btn">Back to Home</a>
        </div>
    </div>
</div>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/components/checkout-thanks.blade.php ENDPATH**/ ?>