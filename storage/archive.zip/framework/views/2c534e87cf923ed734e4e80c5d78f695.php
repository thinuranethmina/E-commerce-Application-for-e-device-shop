<?php $__env->startSection('content'); ?>
    <section class="shop-hero-section">
        <div class="container">
            <div class="row mx-auto">
                <div class="col-md-12">
                    <h2 class="section-subtitle text-center">Don't Miss This Special Opportunity Today.</h2>
                    <h1 class="section-title text-center">Shop And Save Big On Hottest Products</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="shop-filter-section">
        <form id="filter-form" action="<?php echo e(route('shop.index')); ?>" method="GET">
            <div class="container-xxl">
                <div class="row mx-auto">
                    <div class="col-12 position-relative d-flex gap-3">

                        <div class="filter-container" id="filter-container">
                            <div class="content">
                                <div class="row">

                                    <div class="col-12">
                                        <h3 class="section-title d-flex align-items-center gap-3">
                                            <svg class="my-auto" xmlns="http://www.w3.org/2000/svg" width="18px"
                                                height="18px" viewBox="0 0 20 20">
                                                <g id="settings-sliders" transform="translate(0 0)">
                                                    <path id="Path_199" data-name="Path 199"
                                                        d="M.833,3.958h2.28a3.107,3.107,0,0,0,6,0H19.167a.833.833,0,1,0,0-1.667H9.109a3.107,3.107,0,0,0-6,0H.833a.833.833,0,0,0,0,1.667ZM6.111,1.667A1.458,1.458,0,1,1,4.653,3.125,1.458,1.458,0,0,1,6.111,1.667Z"
                                                        transform="translate(0)" />
                                                    <path id="Path_200" data-name="Path 200"
                                                        d="M19.167,10.541h-2.28a3.106,3.106,0,0,0-6,0H.833a.833.833,0,0,0,0,1.667H10.892a3.106,3.106,0,0,0,5.995,0h2.28a.833.833,0,1,0,0-1.667Zm-5.278,2.292a1.458,1.458,0,1,1,1.458-1.458,1.458,1.458,0,0,1-1.458,1.458Z"
                                                        transform="translate(0 -1.375)" />
                                                    <path id="Path_201" data-name="Path 201"
                                                        d="M19.167,18.792H9.109a3.107,3.107,0,0,0-6,0H.833a.833.833,0,1,0,0,1.667h2.28a3.107,3.107,0,0,0,6,0H19.167a.833.833,0,1,0,0-1.667ZM6.111,21.083a1.458,1.458,0,1,1,1.458-1.458,1.458,1.458,0,0,1-1.458,1.458Z"
                                                        transform="translate(0 -2.75)" />
                                                </g>
                                            </svg>
                                            <span>Filter By Price</span>
                                        </h3>
                                        <div class="ps-4">
                                            <span class="filter-label">Price</span>
                                            <div class="range-slider mt-2">
                                                <div class="slider-track"></div>
                                                <div class="slider-range"></div>
                                                <input type="range" id="min-range" name="min_range" min="0"
                                                    max="1000000" value="<?php echo e(request()->min_range ?? 0); ?>">
                                                <input type="range" id="max-range" name="max_range" min="0"
                                                    max="1000000" value="<?php echo e(request()->max_range ?? 1000000); ?>">
                                            </div>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="mt-3 filter-label" id="min-value">100,000</span>
                                                <span class="mt-3 filter-label text-primary" id="max-value">1,000,000</span>
                                            </div>
                                        </div>
                                        <h3 class="section-title d-flex align-items-center gap-3 mt-5">
                                            <svg id="apps" xmlns="http://www.w3.org/2000/svg" width="20"
                                                height="20" viewBox="0 0 20 20">
                                                <path id="Path_39" data-name="Path 39"
                                                    d="M5.833,0h-2.5A3.333,3.333,0,0,0,0,3.333v2.5A3.333,3.333,0,0,0,3.333,9.167h2.5A3.333,3.333,0,0,0,9.167,5.833v-2.5A3.333,3.333,0,0,0,5.833,0ZM7.5,5.833A1.667,1.667,0,0,1,5.833,7.5h-2.5A1.667,1.667,0,0,1,1.667,5.833v-2.5A1.667,1.667,0,0,1,3.333,1.667h2.5A1.667,1.667,0,0,1,7.5,3.333Z" />
                                                <path id="Path_40" data-name="Path 40"
                                                    d="M18.833,0h-2.5A3.333,3.333,0,0,0,13,3.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,18.833,0ZM20.5,5.833A1.667,1.667,0,0,1,18.833,7.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,20.5,3.333Z"
                                                    transform="translate(-2.167)" />
                                                <path id="Path_41" data-name="Path 41"
                                                    d="M5.833,13h-2.5A3.333,3.333,0,0,0,0,16.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,5.833,13ZM7.5,18.833A1.667,1.667,0,0,1,5.833,20.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,7.5,16.333Z"
                                                    transform="translate(0 -2.167)" />
                                                <path id="Path_42" data-name="Path 42"
                                                    d="M18.833,13h-2.5A3.333,3.333,0,0,0,13,16.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,18.833,13ZM20.5,18.833A1.667,1.667,0,0,1,18.833,20.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,20.5,16.333Z"
                                                    transform="translate(-2.167 -2.167)" />
                                            </svg>
                                            <span>Shop By Category</span>
                                        </h3>
                                        <div>
                                            <div class="accordion" id="accordionExample">
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="accordion-item">
                                                        <h2 class="accordion-header">
                                                            <button class="accordion-button collapsed" type="button"
                                                                data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                                aria-expanded="false" aria-controls="collapseThree">

                                                                <svg xmlns="http://www.w3.org/2000/svg" width="20"
                                                                    height="20" viewBox="0 0 20 20">
                                                                    <g id="smartphone" transform="translate(136 -253)">
                                                                        <g id="smartphone-2" data-name="smartphone"
                                                                            transform="translate(-132.667 253)">
                                                                            <path id="Path_36" data-name="Path 36"
                                                                                d="M13.167,0h-5A4.172,4.172,0,0,0,4,4.167V15.833A4.172,4.172,0,0,0,8.167,20h5a4.172,4.172,0,0,0,4.167-4.167V4.167A4.172,4.172,0,0,0,13.167,0Zm-5,1.667h5a2.5,2.5,0,0,1,2.5,2.5v9.167h-10V4.167A2.5,2.5,0,0,1,8.167,1.667Zm5,16.667h-5a2.5,2.5,0,0,1-2.5-2.5V15h10v.833A2.5,2.5,0,0,1,13.167,18.333Z"
                                                                                transform="translate(-4)" />
                                                                            <circle id="Ellipse_1" data-name="Ellipse 1"
                                                                                cx="0.833" cy="0.833" r="0.833"
                                                                                transform="translate(5.833 15.833)" />
                                                                        </g>
                                                                        <g id="Frame_Icon" data-name="Frame Icon"
                                                                            transform="translate(-136 253)">
                                                                            <rect id="Rectangle_1" data-name="Rectangle 1"
                                                                                width="20" height="20"
                                                                                fill="none" />
                                                                        </g>
                                                                    </g>
                                                                </svg>

                                                                <span><?php echo e($category->name); ?></span>
                                                            </button>
                                                        </h2>
                                                        <div id="collapseThree" class="accordion-collapse collapse"
                                                            data-bs-parent="#accordionExample">
                                                            <div class="accordion-body">
                                                                <ul>
                                                                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li>
                                                                            <input type="radio" class="d-none month"
                                                                                name="subcategory"
                                                                                id="subCategory<?php echo e($subcategory->id); ?>">
                                                                            <label class="w-100"
                                                                                for="subCategory<?php echo e($subcategory->id); ?>">
                                                                                <span><?php echo e($subcategory->name); ?></span>
                                                                            </label>
                                                                        </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <h3 class="section-title d-flex align-items-center gap-3 mt-5">
                                            <svg id="apps" xmlns="http://www.w3.org/2000/svg" width="20"
                                                height="20" viewBox="0 0 20 20">
                                                <path id="Path_39" data-name="Path 39"
                                                    d="M5.833,0h-2.5A3.333,3.333,0,0,0,0,3.333v2.5A3.333,3.333,0,0,0,3.333,9.167h2.5A3.333,3.333,0,0,0,9.167,5.833v-2.5A3.333,3.333,0,0,0,5.833,0ZM7.5,5.833A1.667,1.667,0,0,1,5.833,7.5h-2.5A1.667,1.667,0,0,1,1.667,5.833v-2.5A1.667,1.667,0,0,1,3.333,1.667h2.5A1.667,1.667,0,0,1,7.5,3.333Z" />
                                                <path id="Path_40" data-name="Path 40"
                                                    d="M18.833,0h-2.5A3.333,3.333,0,0,0,13,3.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,18.833,0ZM20.5,5.833A1.667,1.667,0,0,1,18.833,7.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,20.5,3.333Z"
                                                    transform="translate(-2.167)" />
                                                <path id="Path_41" data-name="Path 41"
                                                    d="M5.833,13h-2.5A3.333,3.333,0,0,0,0,16.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,5.833,13ZM7.5,18.833A1.667,1.667,0,0,1,5.833,20.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,7.5,16.333Z"
                                                    transform="translate(0 -2.167)" />
                                                <path id="Path_42" data-name="Path 42"
                                                    d="M18.833,13h-2.5A3.333,3.333,0,0,0,13,16.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,18.833,13ZM20.5,18.833A1.667,1.667,0,0,1,18.833,20.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,20.5,16.333Z"
                                                    transform="translate(-2.167 -2.167)" />
                                            </svg>
                                            <span>Brands</span>
                                        </h3>
                                        <div class="ps-4">
                                            <ul>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <label class="filter-label d-flex align-items-center gap-3"
                                                            for="brand<?php echo e($brand->id); ?>">
                                                            <input type="checkbox" class="form-check-input my-auto"
                                                                name="brand[]" value="<?php echo e($brand->id); ?>"
                                                                <?php echo e(is_array(request('brand')) && in_array($brand->id, request('brand')) ? 'checked' : ''); ?>

                                                                id="brand<?php echo e($brand->id); ?>">
                                                            <span class="my-auto"><?php echo e($brand->name); ?></span>
                                                        </label>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                        <h3 class="section-title d-flex align-items-center gap-3 mt-5">
                                            <svg id="apps" xmlns="http://www.w3.org/2000/svg" width="20"
                                                height="20" viewBox="0 0 20 20">
                                                <path id="Path_39" data-name="Path 39"
                                                    d="M5.833,0h-2.5A3.333,3.333,0,0,0,0,3.333v2.5A3.333,3.333,0,0,0,3.333,9.167h2.5A3.333,3.333,0,0,0,9.167,5.833v-2.5A3.333,3.333,0,0,0,5.833,0ZM7.5,5.833A1.667,1.667,0,0,1,5.833,7.5h-2.5A1.667,1.667,0,0,1,1.667,5.833v-2.5A1.667,1.667,0,0,1,3.333,1.667h2.5A1.667,1.667,0,0,1,7.5,3.333Z" />
                                                <path id="Path_40" data-name="Path 40"
                                                    d="M18.833,0h-2.5A3.333,3.333,0,0,0,13,3.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,18.833,0ZM20.5,5.833A1.667,1.667,0,0,1,18.833,7.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,20.5,3.333Z"
                                                    transform="translate(-2.167)" />
                                                <path id="Path_41" data-name="Path 41"
                                                    d="M5.833,13h-2.5A3.333,3.333,0,0,0,0,16.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,5.833,13ZM7.5,18.833A1.667,1.667,0,0,1,5.833,20.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,7.5,16.333Z"
                                                    transform="translate(0 -2.167)" />
                                                <path id="Path_42" data-name="Path 42"
                                                    d="M18.833,13h-2.5A3.333,3.333,0,0,0,13,16.333v2.5a3.333,3.333,0,0,0,3.333,3.333h2.5a3.333,3.333,0,0,0,3.333-3.333v-2.5A3.333,3.333,0,0,0,18.833,13ZM20.5,18.833A1.667,1.667,0,0,1,18.833,20.5h-2.5a1.667,1.667,0,0,1-1.667-1.667v-2.5a1.667,1.667,0,0,1,1.667-1.667h2.5A1.667,1.667,0,0,1,20.5,16.333Z"
                                                    transform="translate(-2.167 -2.167)" />
                                            </svg>
                                            <span>Colours</span>
                                        </h3>
                                        <div class="ps-4">
                                            <ul>
                                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <label class="filter-label d-flex align-items-center gap-3"
                                                            for="color<?php echo e($color->id); ?>">
                                                            <input type="checkbox" class="form-check-input my-auto"
                                                                name="color[]" id="color<?php echo e($color->id); ?>"
                                                                value="<?php echo e($color->id); ?>"
                                                                <?php echo e(is_array(request('color')) && in_array($color->id, request('color')) ? 'checked' : ''); ?>>
                                                            <span class="my-auto"><?php echo e($color->variable); ?></span>
                                                        </label>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>

                                        <div class="mt-5 offers-section">
                                            <?php $__currentLoopData = $banners->where('type', 'shop_sidebar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('frontend.components.offer-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="result-container ps-lg-3">
                            <div class="row position-relative align-items-center">

                                <div class="col-12 text-center col-lg-auto mt-3 mt-lg-0 order-1 order-lg-0">
                                    <span>Showing 1-16 of 20 results</span>
                                </div>
                                <div class="col d-none d-lg-block px-3">
                                    <hr class="divider">
                                </div>
                                <div class="col-12 col-lg-auto order-0 order-lg-1 border border-1 rounded rounded-3">
                                    <div class="row align-items-center justify-content-between">
                                        <div class="col-auto d-flex">
                                            <div>
                                                <select name="" class="form-select filter-select">
                                                    <option value="DESC">Sort By Latest</option>
                                                    <option value="ASC">Sort By Older</option>
                                                </select>
                                            </div>
                                            <div>
                                                <select name="" class="form-select filter-select">
                                                    <option value="12">Show 12 </option>
                                                    <option value="20">Show 20</option>
                                                    <option value="24">Show 24</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-auto d-lg-none">
                                            <button class="btn border-0" onclick="toggleFilter()">
                                                <svg class="d-lg-none" xmlns="http://www.w3.org/2000/svg" width="18px"
                                                    height="18px" viewBox="0 0 20 20">
                                                    <g id="settings-sliders" transform="translate(0 0)">
                                                        <path id="Path_199" data-name="Path 199"
                                                            d="M.833,3.958h2.28a3.107,3.107,0,0,0,6,0H19.167a.833.833,0,1,0,0-1.667H9.109a3.107,3.107,0,0,0-6,0H.833a.833.833,0,0,0,0,1.667ZM6.111,1.667A1.458,1.458,0,1,1,4.653,3.125,1.458,1.458,0,0,1,6.111,1.667Z"
                                                            transform="translate(0)" />
                                                        <path id="Path_200" data-name="Path 200"
                                                            d="M19.167,10.541h-2.28a3.106,3.106,0,0,0-6,0H.833a.833.833,0,0,0,0,1.667H10.892a3.106,3.106,0,0,0,5.995,0h2.28a.833.833,0,1,0,0-1.667Zm-5.278,2.292a1.458,1.458,0,1,1,1.458-1.458,1.458,1.458,0,0,1-1.458,1.458Z"
                                                            transform="translate(0 -1.375)" />
                                                        <path id="Path_201" data-name="Path 201"
                                                            d="M19.167,18.792H9.109a3.107,3.107,0,0,0-6,0H.833a.833.833,0,1,0,0,1.667h2.28a3.107,3.107,0,0,0,6,0H19.167a.833.833,0,1,0,0-1.667ZM6.111,21.083a1.458,1.458,0,1,1,1.458-1.458,1.458,1.458,0,0,1-1.458,1.458Z"
                                                            transform="translate(0 -2.75)" />
                                                    </g>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12 mt-4 product-container order-last">
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('frontend.components.product-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>


                            </div>
                            <div class="col-12 text-end pt-4">
                                <div class="float-end">
                                    <?php echo e($products->links()); ?>

                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </form>
    </section>

    <?php echo $__env->make('frontend.layouts.offers-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.layouts.features-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const minRange = document.getElementById('min-range');
        const maxRange = document.getElementById('max-range');
        const sliderRange = document.querySelector('.slider-range');
        const minValueLabel = document.getElementById('min-value');
        const maxValueLabel = document.getElementById('max-value');
        const minGap = 1000; // Minimum gap between min and max values
        const max = parseInt(maxRange.max);

        function updateSlider() {
            const minValue = parseInt(minRange.value);
            const maxValue = parseInt(maxRange.value);

            // Enforce minimum gap
            if (maxValue - minValue < minGap) {
                if (this === minRange) {
                    minRange.value = maxValue - minGap;
                } else {
                    maxRange.value = minValue + minGap;
                }
            }

            // Update slider range styles
            const minPercent = (minRange.value / max) * 100;
            const maxPercent = (maxRange.value / max) * 100;

            sliderRange.style.left = minPercent + '%';
            sliderRange.style.width = (maxPercent - minPercent) + '%';

            // Update dynamic labels
            minValueLabel.textContent = parseInt(minRange.value).toLocaleString();
            maxValueLabel.textContent = parseInt(maxRange.value).toLocaleString();
        }

        minRange.addEventListener('input', updateSlider);
        maxRange.addEventListener('input', updateSlider);

        minRange.addEventListener('change', submitFilter);
        maxRange.addEventListener('change', submitFilter);

        // Initialize slider positions
        updateSlider();

        document.getElementById('filter-container').addEventListener('click', function(e) {
            if (e.target.classList.contains('filter-container')) {
                e.target.classList.toggle('m-view');
            }
        });

        function toggleFilter() {
            document.getElementById('filter-container').classList.toggle('m-view');
        }

        document.querySelectorAll('input').forEach(item => {
            item.addEventListener('change', submitFilter);
        })

        function submitFilter() {
            document.getElementById('filter-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/pages/shop/index.blade.php ENDPATH**/ ?>