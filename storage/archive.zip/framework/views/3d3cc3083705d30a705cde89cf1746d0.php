<section class="offers-section">
    <div class="container">
        <div class="row mx-auto">

            <div class="col-12">
                <h3 class="section-title text-center">Special Offers and Discount</h3>
            </div>
            <?php $__currentLoopData = $banners->where('type', 'bottom_bar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bottomBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-3 p-3">
                    <a href="<?php echo e($bottomBanner->url); ?>" target="_blank">
                        <div class="card">
                            <img src="<?php echo e(asset($bottomBanner->image)); ?>" alt="<?php echo e($bottomBanner->title); ?>">
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/layouts/offers-section.blade.php ENDPATH**/ ?>