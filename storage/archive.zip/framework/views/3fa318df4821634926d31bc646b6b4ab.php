<?php $__env->startSection('page', 'System Settings'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.components.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row top-row">
        <div class="col-xl-7">
            <div class="card">
                <div class="card-body">
                    <div class="col-lg-12">
                        <h4 class="mb-3 header-title">PayHere settings</h4>

                        <form class="required-form" action="<?php echo e(route('admin.payment_settings.payment_gateway.update')); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label class="form-label" for="payhere_merchant_id">PayHere Merchant ID</label>
                                <input type="text" name="payhere_merchant_id" id="payhere_merchant_id"
                                    class="form-control"
                                    value="<?php echo e(old('payhere_merchant_id', $settings['payment.payhere_merchant_id'] ?? '')); ?>">

                                <?php if($errors->has('payhere_merchant_id')): ?>
                                    <div class="remind-msg"><?php echo e($errors->first('payhere_merchant_id')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label class="form-label" for="payhere_secret_key">PayHere Secret Key</label>
                                <input type="text" name="payhere_secret_key" id="payhere_secret_key" class="form-control"
                                    value="<?php echo e(old('payhere_secret_key', $settings['payment.payhere_secret_key'] ?? '')); ?>">

                                <?php if($errors->has('payhere_secret_key')): ?>
                                    <div class="remind-msg"><?php echo e($errors->first('payhere_secret_key')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label class="form-label" for="refund_policy">Refund policy</label>
                                <input type="text" name="refund_policy" id="refund_policy" class="form-control"
                                    value="<?php echo e(old('refund_policy', $settings['payment.refund_policy'] ?? '')); ?>">

                                <?php if($errors->has('refund_policy')): ?>
                                    <div class="remind-msg" aria-><?php echo e($errors->first('refund_policy')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">Update PayHere Settings</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-5">
            <div class="card">
                <div class="card-body">
                    <div class="col-lg-12">
                        <h4 class="mb-3 header-title">Offline payment settings</h4>

                        <form class="required-form" action="<?php echo e(route('admin.payment_settings.offline.update')); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label class="form-label" for="bank_info">Bank Information</label>

                                <input type="text" class="form-control mb-3" name="bank_name" id="bank_name"
                                    placeholder="Bank Name"
                                    value="<?php echo e(old('bank_name', $settings['payment.bank_name'] ?? '')); ?>">

                                <textarea class="form-control" name="bank_info" id="bank_info" cols="30" rows="5" placeholder=""><?php echo e(old('bank_info', $settings['payment.bank_info'] ?? '')); ?></textarea>

                                <?php if($errors->has('bank_info')): ?>
                                    <div class="remind-msg"><?php echo e($errors->first('bank_info')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">Update Offline Payment</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="col-lg-12">
                        <h4 class="mb-3 header-title">Delivery Fee</h4>

                        <form class="required-form" action="<?php echo e(route('admin.payment_settings.delivery.update')); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label class="form-label" for="delivery_fee">Delivery Fee</label>

                                <input type="text" class="form-control mb-3" name="delivery_fee" id="delivery_fee"
                                    placeholder="Delivery Fee"
                                    value="<?php echo e(old('delivery_fee', $settings['payment.delivery_fee'] ?? '')); ?>">

                            </div>

                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary">Update Delivery Fee</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/pages/settings/payment.blade.php ENDPATH**/ ?>