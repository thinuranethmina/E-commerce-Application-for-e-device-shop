<div class="modal-header">
    <div class="w-100 d-flex justify-content-start">
        <span>View Banner</span>
    </div>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <div class="row">

        <div class="col-12 text-center">
            <div class="form-group d-inline-block">

                <?php
                    $data = [
                        'width' => '200px',
                        'height' => '300px',
                        'maxHeight' => '300px',
                        'name' => 'image',
                        'cover' => false,
                        'type' => 'box',
                        'bgColor' => 'white',
                        'src' => asset($item->image),
                        'purpose' => 'view',
                    ];
                ?>
                <?php echo $__env->make('backend.components.image-chooser', $data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="form-group">
                <label for="title" class="form-label">Title</label>
                <input type="text" id="title" name="title" value="<?php echo e($item->title); ?>" class="form-control"
                    disabled>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="form-group">
                <label for="url" class="form-label">URL</label>
                <input type="text" id="url" name="url" value="<?php echo e($item->url); ?>" class="form-control"
                    disabled>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="form-group">
                <label for="type" class="form-label">Type</label>
                <select name="type" id="type" class="form-select" disabled>
                    <option value="hero" <?php echo e($item->type == 'hero' ? 'selected' : ''); ?>>Hero</option>
                    <option value="bottom_bar" <?php echo e($item->type == 'bottom_bar' ? 'selected' : ''); ?>>Bottom Bar
                    </option>
                    <option value="home_sidebar" <?php echo e($item->type == 'home_sidebar' ? 'selected' : ''); ?>>Home Side Bar
                    </option>
                    <option value="shop_sidebar" <?php echo e($item->type == 'shop_sidebar' ? 'selected' : ''); ?>>Shop Side Bar
                    </option>
                </select>
            </div>
        </div>

        <div class="col-xl-6">
            <div class="form-group">
                <label for="status" class="form-label">Status</label>
                <select name="status" id="status" class="form-select" disabled>
                    <option value="Active" <?php echo e($item->status == 'Active' ? 'selected' : ''); ?>>Active</option>
                    <option value="Inactive" <?php echo e($item->status == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                </select>
            </div>
        </div>


    </div>
</div>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/pages/banner/show.blade.php ENDPATH**/ ?>