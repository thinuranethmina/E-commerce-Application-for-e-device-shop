<form class="ajaxForm" action="<?php echo e(route('admin.variation.update', $item->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="modal-header">
        <div class="w-100 d-flex justify-content-start">
            <span>Edit Variation</span>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <div class="row">

            <div class="col-xl-10 col-12 mx-auto">
                <div class="form-group">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" id="name" name="name" value="<?php echo e($item->name); ?>"
                        class="form-control">
                </div>
            </div>

            <div class="col-xl-10 col-12 mx-auto">
                <div class="form-group" id="variationContainer">
                    <label for="values" class="form-label">Values</label>

                    <?php $__currentLoopData = $item->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->first): ?>
                            <div class="row mb-2">
                                <div class="col pe-0">
                                    <input type="text" id="name" name="values[<?php echo e($value->id); ?>]"
                                        value="<?php echo e($value->variable); ?>" class="form-control">
                                </div>
                                <div class="col-auto">
                                    <button type="button" class="btn btn-primary h-100" onclick="addVariationValue()">
                                        <span class="fi fi-rr-add d-flex"></span>
                                    </button>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="row mb-2">
                                <div class="col pe-0">
                                    <input type="text" id="name" name="values[<?php echo e($value->id); ?>]"
                                        value="<?php echo e($value->variable); ?>" class="form-control">
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn close-btn" onclick="closeModal();">Close</button>
        <button type="submit" class="btn save-btn">Save</button>
    </div>

</form>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/pages/variation/edit.blade.php ENDPATH**/ ?>