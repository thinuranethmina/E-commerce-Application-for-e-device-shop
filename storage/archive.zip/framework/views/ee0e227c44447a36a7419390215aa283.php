<?php $__env->startSection('content'); ?>
    <div class="row top-row dashboard">
        <div class="col-12 mb-3">
            <?php echo $__env->make('backend.components.greeting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h4 class="username text-capitalize"><?php echo e(Auth::user()->first_name . ' ' . Auth::user()->last_name); ?></h4>
        </div>
        <div class="col-12 overview">
            <h4 class="section-title">Overview</h4>
            <div class="row">
                <div class="col-xl-3">
                    <div class="card bg-pink">
                        <div class="card-body">
                            <h5 class="card-title text-white">Total Students</h5>
                            <p class="card-text text-white">xx</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="card bg-orange">
                        <div class="card-body">
                            <h5 class="card-title text-white">Total Teachers</h5>
                            <p class="card-text text-white">xxx</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="card bg-purple">
                        <div class="card-body">
                            <h5 class="card-title text-white">Total Courses</h5>
                            <p class="card-text text-white">xxx</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="card bg-blue">
                        <div class="card-body">
                            <h5 class="card-title text-white">Total Received Payments</h5>
                            <p class="card-text text-white">xxx</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/pages/dashboard.blade.php ENDPATH**/ ?>