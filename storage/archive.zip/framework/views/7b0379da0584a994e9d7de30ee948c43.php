<div class="row mb-2">
    <div class="col pe-0">
        <select name="product_variation[<?php echo e($index); ?>][variationName][<?php echo e($index2); ?>]"
            onchange="getVariationValue(this)" class="form-select">
            <option value="">Select Variation
            </option>
            <?php $__currentLoopData = $variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($variation->id); ?>"><?php echo e($variation->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col pe-0">
        <select name="product_variation[<?php echo e($index); ?>][variationValue][<?php echo e($index2); ?>]"
            class="form-select variationValue">
        </select>
    </div>
    <div class="col-auto">
        <button type="button" class="btn btn-dark h-100" onclick="removeVariationValue(this)">
            <span class="fi fi-rr-minus-circle d-flex"></span>
        </button>
    </div>
</div>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/pages/product/variation-row.blade.php ENDPATH**/ ?>