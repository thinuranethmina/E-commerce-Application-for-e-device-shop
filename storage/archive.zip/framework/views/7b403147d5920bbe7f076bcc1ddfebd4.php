<div class="modal fade mainModal" id="mainModal" tabindex="-1" aria-labelledby="mainModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" id="modalContent">

        </div>
    </div>
</div>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/layouts/modal.blade.php ENDPATH**/ ?>