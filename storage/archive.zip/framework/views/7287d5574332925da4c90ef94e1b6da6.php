<?php $__env->startSection('content'); ?>
    <section class="checkout-section">
        <div class="container-xxl">
            <form action="<?php echo e(route('checkout.store')); ?>" id="checkoutForm" enctype="multipart/form-data" method="post">
                <?php echo csrf_field(); ?>
                <div class="row mx-auto align-items-start">

                    <div class="col-12 col-lg-6 col-xl-7 mt-5 mt-lg-0">
                        <h1 class="section-title">Checkout</h1>

                        <div class="row">
                            <div class="col-12">
                                <div class="payment-method-card">
                                    <h2 class="title">Choose Payment Method</h2>

                                    <input type="radio" class="d-none form-check-input" id="card-payment"
                                        name="payment_method" value="card">
                                    <label for="card-payment" class="d-block">
                                        <div class="card">
                                            <div class="circle"></div>
                                            <p>
                                                Credit Or Debit Card
                                            </p>
                                            <div class="d-none d-xl-block flex-grow-1 text-end">
                                                <img class="payment-methods-image"
                                                    src="<?php echo e(asset('assets/frontend/images/footer/payment_methods.webp')); ?>"
                                                    alt="">
                                            </div>
                                        </div>
                                    </label>

                                    <input type="radio" class="d-none form-check-input" id="bank-transfer"
                                        name="payment_method" value="bank">
                                    <label for="bank-transfer" class="d-block mt-3">
                                        <div class="card">
                                            <div class="circle"></div>
                                            <p>
                                                Bank Transfer
                                            </p>
                                        </div>
                                    </label>

                                    <div class="mt-4 bank-trnsfer-info">

                                        <p class="section-description">Please Transfer The Full Amount To Any Below Bank
                                            Account.
                                        </p>

                                        <pre class="bank-details"><?php echo e($settings['payment.bank_info']); ?></pre>
                                        <p class="section-description">Whatsapp Deposit Slip To This Number PHONE NO :
                                            <a href="https://wa.me/770257357">0770 257 357</a>
                                            Your Order Will Not Ship Until
                                            We Receive Payment.
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 ">
                                <div class="buyer-details-card">
                                    <h2 class="title">Buyer Details</h2>
                                    <div class="row">

                                        <input type="hidden" value="<?php echo e($ref); ?>" name="ref">

                                        <div class="col-12 col-lg-6 form-group">
                                            <input type="text" class="form-control" name="firstname"
                                                placeholder="First Name" value="">
                                        </div>

                                        <div class="col-12 col-lg-6 form-group">
                                            <input type="text" class="form-control" name="lastname"
                                                placeholder="Last Name">
                                        </div>

                                        <div class="col-12 form-group">
                                            <input type="text" class="form-control" name="address" placeholder="Address">
                                        </div>

                                        <div class="col-12 form-group">
                                            <input type="number" class="form-control" name="phone" placeholder="Phone">
                                        </div>

                                        <div class="col-12 form-group">
                                            <input type="email" class="form-control" name="email" placeholder="Email">
                                        </div>

                                        <h3 class="title">Note</h3>

                                        <div class="col-12 form-group">
                                            <textarea class="form-control" rows="5" name="note" placeholder="Order Notes (Optional)"></textarea>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-lg-6 col-xl-5 ">
                        <div class="order-summery-card">
                            <div class="px-3 px-lg-4">
                                <h2 class="title text-center">Your Order Summary</h2>
                                <div class="cart-items">
                                    <?php $__currentLoopData = $cartProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('frontend.components.product-card-checkout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="d-flex align-items-center justify-content-between">
                                    <span>Subtotal</span>
                                    <span class="sub-total">Rs <?php echo e(number_format($cartTotal, 2)); ?></span>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mt-1">
                                    <span>Delivery Fee</span>
                                    <span>Rs <?php echo e(number_format($settings['payment.delivery_fee'], 2)); ?></span>
                                </div>
                            </div>

                            <div class="total-card mt-4">
                                <span class="total-label">Total</span>
                                <span class="total-price">Rs
                                    <?php echo e(number_format($cartTotal + $settings['payment.delivery_fee'], 2)); ?></span>
                            </div>

                            <button type="submit" class="btn primary-gradiant-btn mt-3">
                                Process To Checkout
                            </button>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </section>

    <?php echo $__env->make('frontend.layouts.features-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="module">
        <?php
            if (isset($html)) {
                echo 'openModal(`' . $html . '`);';
            }
        ?>
    </script>
    <script type="module">
        document.querySelectorAll('.order-summery-card .cart-item .item-quantity .btn').forEach(button => {
            button.addEventListener('click', function(event) {

                let subTotal = 0;
                let grandTotal = 0;

                document.querySelectorAll('.order-summery-card .cart-item .item-quantity').forEach(
                    itemQuantity => {
                        const qty = itemQuantity.querySelector('.quantity');
                        const price = itemQuantity.querySelector('.price');
                        const totalValue = price.value * qty.value;

                        subTotal += totalValue;
                    });

                document.querySelector('.order-summery-card .sub-total').innerHTML = new Intl.NumberFormat(
                    'en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                    }).format(subTotal);

                document.getElementById('header-cart-total').innerHTML = new Intl.NumberFormat(
                    'en-US', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                    }).format(subTotal);

                document.querySelector('.order-summery-card .total-price').innerHTML = new Intl
                    .NumberFormat(
                        'en-US', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2,
                        }).format(subTotal + <?php echo e($settings['payment.delivery_fee']); ?>);

            });
        });


        if (document.getElementById('checkoutForm')) {
            checkoutFormProcess();
        }

        function checkoutFormProcess() {

            var form = document.getElementById('checkoutForm');

            form.addEventListener("submit", (event) => {
                event.preventDefault();

                const submitButton = form.querySelector('[type="submit"]');
                if (submitButton) {
                    submitButton.disabled = true;
                    submitButton.innerHTML =
                        '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>' +
                        submitButton.innerHTML;
                }

                const formData = new FormData(form);


                fetch(form.action, {
                        method: form.method,
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')
                                .getAttribute(
                                    'content'),
                        },
                        body: formData,
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (submitButton) {
                            submitButton.disabled = false;
                            submitButton.innerHTML = submitButton.textContent;
                        }

                        if (data.success) {
                            if (formData.get('payment_method') == 'card') {
                                payWithPayhere(formData, data.hash, data.total, data.app_url);
                            } else {

                                if (data.html) {
                                    openModal(data.html);
                                } else {
                                    showToast(data.message);
                                    setTimeout(() => {
                                        window.location.href = data.redirect;
                                    }, 3000);
                                }

                            }
                        } else {
                            showToast(data.message);
                        }
                    })
                    .catch(error => {
                        if (submitButton) {
                            submitButton.disabled = false;
                        }
                        console.error('Error:', error);
                        showToast('An error occurred.');
                    });
            });
        }



        function payWithPayhere(form, hash, total, app_url) {

            // Payment completed. It can be a successful failure.
            payhere.onCompleted = function onCompleted(orderId) {
                console.log("Payment completed. OrderID:" + orderId);
                window.location.href = app_url + '/checkout/' + orderId;
            };

            // Payment window closed
            payhere.onDismissed = function onDismissed() {
                // Note: Prompt user to pay again or show an error page
                console.log("Payment dismissed");
            };

            // Error occurred
            payhere.onError = function onError(error) {
                // Note: show an error page
                console.log("Error:" + error);
            };

            const returnUrl = encodeURIComponent(app_url + '/DMX-250127-86294');


            // Put the payment variables here
            var payment = {
                "sandbox": true,
                "merchant_id": "<?php echo e($settings['payment.payhere_merchant_id']); ?>",
                "return_url": app_url + '/<?php echo e($ref); ?>',
                "cancel_url": app_url + '/checkout',
                "notify_url": app_url + '/notify',
                "order_id": "<?php echo e($ref); ?>",
                "items": "DigiMax.lk",
                "amount": total,
                "currency": "LKR",
                "hash": hash,
                "first_name": form.get('firstname'),
                "last_name": form.get('lastname'),
                "email": form.get('email'),
                "phone": form.get('phone'),
                "address": form.get('address'),
                "city": "Colombo",
                "country": "Sri Lanka",
                "delivery_address": "No. 46, Galle road, Kalutara South",
                "delivery_city": "Kalutara",
                "delivery_country": "Sri Lanka",
                "custom_1": "",
                "custom_2": ""
            };

            payhere.startPayment(payment);

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/pages/checkout/index.blade.php ENDPATH**/ ?>