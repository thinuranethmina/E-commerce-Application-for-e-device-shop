<style>
    .modal {
        align-content: space-around !important;
    }

    @media (min-width: 576px) {
        .modal-dialog {
            max-width: 850px !important;
        }
    }
</style>

<div class="modal fade mainModal" id="mainModal" tabindex="-1" aria-labelledby="mainModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body" id="modalContent">


            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/layouts/modal.blade.php ENDPATH**/ ?>