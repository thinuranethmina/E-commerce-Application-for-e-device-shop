<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?></title>

    <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>

    <!-- Boostrap -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendors/bootstrap/bootstrap.min.css')); ?>?v=5.3">

    <!-- Owl Carousel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">

    <!-- Toastify -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastify-js/1.6.1/toastify.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastify-js/1.6.1/toastify.min.js"></script>

    <link rel="stylesheet"
        href="<?php echo e(asset('assets/frontend/css/frontend.css')); ?>?v=<?php echo e(filemtime(public_path('assets/frontend/css/frontend.css'))); ?>">

</head>

<body>

    <?php echo $__env->make('frontend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('frontend.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="overlay" class="overlay"></div>
    <?php echo $__env->make('frontend.layouts.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('assets/frontend/js/jquery.min.js')); ?>?v=3.7.1"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="<?php echo e(asset('assets/frontend/js/bootstrap.bundle.min.js')); ?>?v=5.3"></script>
    <script
        src="<?php echo e(asset('assets/frontend/js/frontend.js')); ?>?v=<?php echo e(filemtime(public_path('assets/frontend/js/frontend.js'))); ?>">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <?php if(session('error')): ?>
        <script type="text/javascript">
            showToast("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <script type="text/javascript">
            showToast("<?php echo e(session('success')); ?>");
        </script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/app.blade.php ENDPATH**/ ?>