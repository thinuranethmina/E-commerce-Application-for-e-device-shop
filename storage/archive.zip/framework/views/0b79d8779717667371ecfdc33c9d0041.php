<?php if($cart_product): ?>
    <div id="cart-item-<?php echo e($cart_product->id); ?>" class="cart-item">
        <div class="item-close">
            <button class="btn btn-close" onclick="removeCartItem(<?php echo e($cart_product->id); ?>)"></button>
        </div>
        <div class="item-image">
            <img src="<?php echo e(asset($cart_product->productVariation->product->thumbnail)); ?>" alt="item">
        </div>
        <div class="item-details flex-grow-1">
            <h4 class="item-title"><?php echo e($cart_product->productVariation->product->name); ?></h4>
            <span class="item-color">
                <?php $__currentLoopData = $cart_product->productVariation->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($type->variationValue->variable); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </span>
            <?php
                $cart_product->productVariation->stock >= $cart_product->qty
                    ? ($qty = $cart_product->qty)
                    : ($qty = $cart_product->productVariation->stock);
            ?>
            <div class="d-flex align-items-center justify-content-between gap-1 mt-2">
                <p class="item-price">Rs <?php echo e(number_format($cart_product->productVariation->price * $qty, 2)); ?></p>
                <div class="item-quantity">
                    <input type="hidden" class="price" value="<?php echo e($cart_product->productVariation->price); ?>">
                    <input type="hidden" class="item-id" value="<?php echo e($cart_product->id); ?>">
                    <button type="button" class="btn btn-minus">-</button>
                    <input type="number" class="quantity" value="<?php echo e($qty); ?>" min="1"
                        max="<?php echo e($cart_product->productVariation->stock); ?>" readonly>
                    <button type="button" class="btn btn-plus">+</button>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div>
        <p>Product not found in the cart.</p>
    </div>
<?php endif; ?>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/components/product-card-checkout.blade.php ENDPATH**/ ?>