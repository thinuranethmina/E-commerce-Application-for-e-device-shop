<div class="category-navigation">
    
    <ul class="categories" id="categories">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <input type="checkbox" id="category-<?php echo e($category->id); ?>" class="category form-check-input"
                    <?php echo e(isset($product) ? ($product->subCategory->category->id == $category->id ? 'checked' : '') : ''); ?>>
                <label for="category-<?php echo e($category->id); ?>"><?php echo e($category->name); ?> Category</label>
                <ul class="subcategories">
                    <?php $__currentLoopData = $category->subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <label for="subcategory-<?php echo e($subcategory->id); ?>">
                                <input type="checkbox" id="subcategory-<?php echo e($subcategory->id); ?>" name="sub_category_id"
                                    class="subcategory form-check-input" data-category="category-<?php echo e($category->id); ?>"
                                    value="<?php echo e($subcategory->id); ?>"
                                    <?php echo e(isset($product) ? ($product->sub_category_id == $subcategory->id ? 'checked' : '') : ''); ?>>
                                <?php echo e($subcategory->name); ?></label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if($category->subcategories->count() == 0): ?>
                        <li>
                            No Related Sub Category
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/components/categoryNavigation.blade.php ENDPATH**/ ?>