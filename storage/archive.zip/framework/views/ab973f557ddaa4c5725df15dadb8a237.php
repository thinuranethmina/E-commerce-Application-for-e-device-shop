<?php $__env->startSection('content'); ?>
    <section class="view-product-section">
        <div class="container">
            <div class="row mx-auto">

                <style>
                    .view-product-section .thumbnail_slider {
                        max-width: 700px;
                        margin: 30px auto;
                    }

                    .view-product-section .splide__slide {
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 400px;
                        width: 580px;
                        overflow: hidden;
                        transition: .2s;
                        border-width: 2px !important;
                        margin-bottom: 10px;
                    }

                    .view-product-section .splide--fade>.splide__track>.splide__list>.splide__slide {
                        border-radius: 6px !important;
                    }

                    .view-product-section .splide--nav>.splide__track>.splide__list>.splide__slide.is-active {
                        border: 1px solid var(--border-color) !important;
                        border-radius: 6px !important;
                    }

                    .view-product-section .splide__slide img {
                        width: auto;
                        height: auto;
                        margin: auto;
                        display: block;
                        max-width: 100%;
                        max-height: 100%;
                        border-radius: 6px !important;
                    }

                    .splide__arrow {
                        background-color: rgba(190, 190, 190, 0.1) !important;
                    }
                </style>

                <div class="col-12 col-lg-7">

                    <div class="thumbnail_slider">
                        <div id="primary_slider">
                            <div class="splide__track">
                                <ul class="splide__list">
                                    <li class="splide__slide" onclick="viewImage(this);">
                                        <img src="<?php echo e(asset($product->thumbnail)); ?>">
                                    </li>
                                    <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="splide__slide" onclick="viewImage(this);">
                                            <img src="<?php echo e(asset($gallery->image)); ?>">
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>

                        <div id="thumbnail_slider">
                            <div class="splide__track">
                                <ul class="splide__list">
                                    <li class="splide__slide">
                                        <img src="<?php echo e(asset($product->thumbnail)); ?>">
                                    </li>
                                    <?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="splide__slide">
                                            <img src="<?php echo e(asset($gallery->image)); ?>">
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <!-- Thumbnal Slider End-->
                    </div>

                </div>

                <div class="col-12 col-lg-5 mt-5 mt-lg-0">
                    <h1 class="product-title"><?php echo e($product->name); ?></h1>
                    <span class="stock-availability" id="availability">Availability:
                        <?php echo e($product->totalStock() <= 0 ? 'Out Of Stock' : 'In Stock'); ?></span>
                    <div class="d-xl-inline-block mt-3 mt-xl-0 ms-xl-3">
                        <div class="stars">
                            <?php for($i = 0; $i < 4; $i++): ?>
                                <div class="star-fill">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em"
                                        viewBox="0 0 24 24">
                                        <path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="2"
                                            d="m12 2l2.939 5.955l6.572.955l-4.756 4.635l1.123 6.545L12 17l-5.878 3.09l1.123-6.545L2.489 8.91l6.572-.955z">
                                        </path>
                                    </svg>
                                </div>
                            <?php endfor; ?>
                            <div class="star-outline">
                                <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24">
                                    <path fill="none" stroke="currentColor" stroke-linejoin="round" stroke-width="2"
                                        d="m12 2l2.939 5.955l6.572.955l-4.756 4.635l1.123 6.545L12 17l-5.878 3.09l1.123-6.545L2.489 8.91l6.572-.955z">
                                    </path>
                                </svg>
                            </div>
                        </div>
                        <span class="rating"><?php echo e($product->reviewRate()); ?></span>
                        <span class="rating-count">(<?php echo e($product->reviews->where('status', 'Active')->count()); ?>

                            Reviews)</span>
                    </div>

                    <p id="product-price" class="price my-4">RS <?php echo e(number_format($product->variations[0]->price, 2)); ?>/=</p>
                    <input readonly type="text" id="original-price" value="<?php echo e($product->variations[0]->price); ?>">

                    <?php if($product->warranty_info): ?>
                        <div class="warrenty-card mb-4">
                            <p class="warrenty-title">
                                <svg xmlns="http://www.w3.org/2000/svg" width="19" height="20"
                                    viewBox="0 0 19.748 20.585">
                                    <path id="features-alt"
                                        d="M4.668,14.831a.792.792,0,0,0,1.352-.561v-3.44a2.929,2.929,0,1,0-4.184,0v3.44a.792.792,0,0,0,1.367.545l.724-.8.739.817ZM1.837,8.787A2.092,2.092,0,1,1,3.929,10.88,2.095,2.095,0,0,1,1.837,8.787Zm.837,5.368V11.423a2.829,2.829,0,0,0,2.511,0v2.732L4.239,13.11a.43.43,0,0,0-.621,0Zm5.021,2.164a.419.419,0,0,1,.418-.418h7.532a.418.418,0,1,1,0,.837H8.113A.419.419,0,0,1,7.695,16.319ZM8.95,10.043a.418.418,0,0,1,0-.837h6.695a.418.418,0,0,1,0,.837Zm-.837,2.511h7.532a.418.418,0,1,1,0,.837H8.113a.418.418,0,1,1,0-.837ZM18.655,4.51,15.738,1.594A5.4,5.4,0,0,0,11.892,0H7.276A3.771,3.771,0,0,0,3.51,3.767a.418.418,0,1,0,.837,0A2.932,2.932,0,0,1,7.276.838h4.615a4.641,4.641,0,0,1,.824.08V5.441a2.1,2.1,0,0,0,2.092,2.092h4.522a4.656,4.656,0,0,1,.08.824V16.32a2.932,2.932,0,0,1-2.929,2.929H7.276a2.927,2.927,0,0,1-2.837-2.2.419.419,0,0,0-.811.209,3.764,3.764,0,0,0,3.647,2.824h9.206a3.771,3.771,0,0,0,3.766-3.766V8.357A5.408,5.408,0,0,0,18.654,4.51ZM14.808,6.7A1.257,1.257,0,0,1,13.553,5.44V1.154a4.586,4.586,0,0,1,1.593,1.031L18.063,5.1a4.58,4.58,0,0,1,1.03,1.593H14.808Z"
                                        transform="translate(-0.749 0.249)" fill="#0db5ab" stroke="#0db5ab"
                                        stroke-width="0.5" />
                                </svg>
                                <span>Warranty</span>
                            </p>
                            <p class="warrenty-description">
                                <?php echo e($product->warranty_info); ?>

                            </p>
                        </div>
                    <?php endif; ?>

                    <form id="variation-form" action="<?php echo e(route('shop.product.price.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <div class="row variation-container" id="variation-container">
                            <div class="col-12">
                                <label class="form-label" for="qty">Select Quantity</label>
                                <div class="d-flex align-items-center gap-1">
                                    <button type="button" class="btn" onclick="chnageQty('-');">-</button>
                                    <input type="number" class="form-control" name="qty" id="qty" min="1"
                                        value="1" readonly>
                                    <button type="button" class="btn" onclick="chnageQty('+');">+</button>
                                </div>
                            </div>
                            <?php if($product->attributes()->count() >= 1): ?>
                                <div class="col-12">
                                    <div class="row">
                                        <?php $__currentLoopData = $product->attributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col">
                                                <label class="form-label">Select <?php echo e($attribute->name); ?> </label>
                                                <div>
                                                    <select class="form-select filter" name="<?php echo e($attribute->name); ?>"
                                                        data-variation-id="<?php echo e($attribute->id); ?>"
                                                        onchange="changeAttributesValues(this);">
                                                        <option value="">Select <?php echo e($attribute->name); ?></option>
                                                        <?php $__currentLoopData = $product->attributeValues($attribute->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item->id); ?>"
                                                                <?php if($item->id == $product->attributeValues($attribute->id)->first()->id): ?> selected <?php endif; ?>>
                                                                <?php echo e($item->variable); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </form>

                    <div class="btn-controllers mt-4">
                        <div class="d-flex align-items-center justify-content-start gap-3">
                            <button id="detail-addtocart-btn" class="btn primary-btn d-inline-flex"
                                data-variation-id="<?php echo e($product->variations[0]->id); ?>" onclick="addToCart(this)">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Outline" viewBox="0 0 24 24"
                                    width="22" height="22">
                                    <circle fill="white" cx="7" cy="22" r="2" />
                                    <circle fill="white" cx="17" cy="22" r="2" />
                                    <path fill="white"
                                        d="M23,3H21V1a1,1,0,0,0-2,0V3H17a1,1,0,0,0,0,2h2V7a1,1,0,0,0,2,0V5h2a1,1,0,0,0,0-2Z" />
                                    <path fill="white"
                                        d="M21.771,9.726a.994.994,0,0,0-1.162.806A3,3,0,0,1,17.657,13H5.418l-.94-8H13a1,1,0,0,0,0-2H4.242L4.2,2.648A3,3,0,0,0,1.222,0H1A1,1,0,0,0,1,2h.222a1,1,0,0,1,.993.883l1.376,11.7A5,5,0,0,0,8.557,19H19a1,1,0,0,0,0-2H8.557a3,3,0,0,1-2.829-2H17.657a5,5,0,0,0,4.921-4.112A1,1,0,0,0,21.771,9.726Z" />
                                </svg>
                                <span>Add to Cart</span>
                            </button>
                            <div class="d-inline-flex align-items-center justify-content-center gap-2 my-auto">
                                <button class="btn share-btn">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22"
                                        height="22">
                                        <g id="_01_align_center" data-name="01 align center">
                                            <path fill="black"
                                                d="M19.333,14.667a4.66,4.66,0,0,0-3.839,2.024L8.985,13.752a4.574,4.574,0,0,0,.005-3.488l6.5-2.954a4.66,4.66,0,1,0-.827-2.643,4.633,4.633,0,0,0,.08.786L7.833,8.593a4.668,4.668,0,1,0-.015,6.827l6.928,3.128a4.736,4.736,0,0,0-.079.785,4.667,4.667,0,1,0,4.666-4.666ZM19.333,2a2.667,2.667,0,1,1-2.666,2.667A2.669,2.669,0,0,1,19.333,2ZM4.667,14.667A2.667,2.667,0,1,1,7.333,12,2.67,2.67,0,0,1,4.667,14.667ZM19.333,22A2.667,2.667,0,1,1,22,19.333,2.669,2.669,0,0,1,19.333,22Z" />
                                        </g>
                                    </svg>
                                </button>
                                <span>Share</span>
                            </div>
                        </div>
                        <button class="btn secondary-btn mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" id="Layer_1" data-name="Layer 1"
                                viewBox="0 0 24 24" width="22" height="22">
                                <path fill="white"
                                    d="M11.24,24a2.262,2.262,0,0,1-.948-.212,2.18,2.18,0,0,1-1.2-2.622L10.653,16H6.975A3,3,0,0,1,4.1,12.131l3.024-10A2.983,2.983,0,0,1,10,0h3.693a2.6,2.6,0,0,1,2.433,3.511L14.443,8H17a3,3,0,0,1,2.483,4.684l-6.4,10.3A2.2,2.2,0,0,1,11.24,24ZM10,2a1,1,0,0,0-.958.71l-3.024,10A1,1,0,0,0,6.975,14H12a1,1,0,0,1,.957,1.29L11.01,21.732a.183.183,0,0,0,.121.241A.188.188,0,0,0,11.4,21.9l6.4-10.3a1,1,0,0,0,.078-1.063A.979.979,0,0,0,17,10H13a1,1,0,0,1-.937-1.351l2.19-5.84A.6.6,0,0,0,13.693,2Z" />
                            </svg>
                            <span>Quick Buy</span>
                        </button>
                    </div>

                </div>

            </div>
        </div>
    </section>

    <section class="product-description-section">
        <div class="container">
            <div class="row mx-auto">
                <div class="col-12">
                    <h3 class="section-title">Description</h3>

                    <?php echo e($product->description); ?>


                </div>
            </div>
        </div>
    </section>

    <section class="product-review-section">
        <div class="container">
            <div class="row mx-auto align-items-center">

                <div class="col-12 col-lg-6">
                    <div class="row align-items-center">

                        <div class="col-auto">
                            <h3 class="section-title d-inline">Reviews</h3>
                            <span class="review-count">(<?php echo e($reviews->count()); ?>)</span>
                        </div>
                        <div class="col d-none d-lg-block px-3">
                            <hr class="divider">
                        </div>

                        <div class="col-12 mt-4 px-4">
                            <div class="row">

                                <?php $__currentLoopData = $reviews->paginate(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 mb-5">
                                        <div class="review-card">
                                            <div class="d-flex align-items-center gap-3">
                                                <div class="image-wrapper">
                                                    <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTEhIVFhUVFRcXFRUVFhUWFRUVFRcXFxUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGC0dHR0tLS0tLS0tLS0tLS0tLS0tLS0tKy0tKy0tKy0tLSsrLS0tLS0tLS0tLSstLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAgMEBQYHAQj/xABHEAABAgMEBQgHBQYFBQEAAAABAAIDBBEFEiExBkFRYXEHIjJygZGhsRMjM1LB0fAUQlNi4RYkNIKSshUXY3Oig5OzwuJD/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAIxEBAQACAgMBAAIDAQAAAAAAAAECEQMxEiFBBDJRE2FxIv/aAAwDAQACEQMRAD8A0oziH2vDJKX4e5C9DSBKFNBxyTrDYkAYaP8AaG7UAsKLoSIjt2owjN2oBU5KlaVHnDirpfBGCpGlp5zeKAhr6Se5cJTK0pwQ27XHIbSkDiHNtY9peaAHiTwAzUzE5RIcLmtgPPEtb4YlUZ8elXE1cczsrqAUfHnMaAcTrJoNfaVchNB/zGiEXnQA1u0vJceDQB4qNtXTR8xDLfQFrTgTeFewHNUxk4MS7E1oK6gE2tOadfeW4XjXDDA6kBIm7vHWoEPRO1CvBMoVnEAOeC4uFQK0qM8+FUJWK4OwBaNxNKGpx7B4KbbD1DiqAcjtm4b8y4HDPHxzXYss4YjnDaMU5lsrBLyFUmHLtVSR6oVRKrtUAaq6Ck0aqAUg4vZ12+YW2xuiOCxKTxjQx/qN/uC2yZPN7EslR2R6PafNO2hNLM6A4nzT5oUQxaIJRBMMUGkk3+Me4fJHGk83+L4BRVFxBJgaVTfvjuRxpbNe8O5QaCCWBul81tb3H5pZumMz+XuKrYSiA2fRaddFgte7Nza4KE0wzbxUloSf3ZnVCb2/DDniqFKq+IA01VVtCYJeanJW3SOJCaABiRiaFUSfiC+SNaJAJGmK17ExixEsWE6lz7M7YU9jRsXlcmYlSDrxHx+KWfLnYkzAOzwS2fiWE87miv3SOymXgnU1PH0IGs18QG+Si/RkHsScZ+Q2D4pA5hTAwrUgatvyVosqec5ousaD0TVuBGq875qlwnHV5KcsybcCK4gZAnAcApzh4pO1ZIs51AK5gEGm8EYEKNvKXdLOiML4kTHMCowpmM8vkoeK0tND3jEEbQVXHlv0Wc0NVdqkryF5aIKgo1UkCjgoB1ZYrHhf7jfMLZ5w4dixqwxWZgj/AFG+a2KdOBU5HC9j+yHE+akGhR1h+yHE+ak2hKG5RBGQTDAFxdRSkTiFVwlFqgizSjApFrko0oNr2hzqSrD+UKnaT28Yk0YcMijMCd/BPp/SBslZ7BnFfDpDbvI6R3BZxZMQ3rxOeJJ+s0Q03a771Git767UtJ6OOdQnu1qR0Tsr0jjFcKgYCu3arxLSoyopyy+NMcftVGX0VbsSx0aaru+CAMFHTGayz22wkqoxdG27q7aKOmNHiMhUK6uSTwsblW8wjOpixvr9FFzNiHMA8KUK1GJJtdmAmwsiuBFdh19u1L/LYV4sayWLKObhilJeSOZcG8ak9y0O09GDQkDgdap9oyl3B9ezLuW2HNMvTDPh8fZWUpS62+7gbo30SE6NxFDQg57ijSUZjCMRuqnM3abX814DmkUBAAcw6iCM27lWN1kzs3EVeQDkk40KAcuhicNKOCkGlKsKZJXRoVm4PXHxWuzxwKybRFtZ2D1j5FaxPZFRThxYHshxPmpVoUVo77EcT5qWaETo3aILqCA8+VRSUmYiI6IkQ7nIl5Juei3kwWDkvAxIG0pkHJ5ZcdrYrHOxAcCeFUA95QWua6A1x/8AzvHdXId3xUTY8IvcBRT3Kc5r40IgYlp7WilPMpvovC5wR0caLYcAMhtaNilIb6FR8vgAE7hlYb9uqT0dvjYfqo6K7FPojcFHxRipzq+OEiUm4o5CIQsK3hRjKp/LsTGApGWUUzz7OCKUVL0zsEBpiNGWavcJM7Zgh0MimpZeWrstb9MCm5e67EVAyzrRcmnBtLusA7frFTtvy9w7gadh+vNV2do0NAzxHYvR475SVw5zxFdEriuByQDkZrl0MTprkswpswpxDTCxaECs7C7fJajPnArMtAG1nWbmu8lpVoZFTRDzRr2I4nzUy1Qui/sBxPmppqJ0HUEZBAVf9iJT8JqH7ESn4TO5V88ocHa7+kov+YcL83cUgsf7Eyn4TO5c/YuU/CZ3Ku/5hQvzdxSUblFhDMu/pKAtI0OlfwmdwRm6JyzcWwmVGWAVObylwTrd/SU6g8o8uc3O/pKZK7ynywZMQ2tz9GT3uNfJE0IhXn9UYoad2pDmHwosPnC6anEdE1GB7U/5Pm+pe+mb/IJZdLw7XGCyqew2tGJIVStSfeNYA92qgJ+1o56BzzoQs8cGtzabGmm03JjEeCcFmEK2IoNHXu/BWGyrYJoCe9Z8mNjbiylWqi4GpnDmwUo2aWG3To+hwwpCWh5Krx7TLddAmX7Zlpwy4aktb6TctNDaESabVpG5V6Q0ra+lRnvU9LzTYgq3VmNYWGeNgxsrL9NIFASs9jPy3LS9MqViN9113+oVCzGYwK9D8/8AFxc/8nA5GaUiCjtK6GB1DKdQimcNO4SZrbyctrOcGOWiWieaeCz/AJNG/vLzshlXy0jzSpyESOi3sG8T5qbaoTRX+HbxPmptqJ0Tq6ggmHm4Q0YQkqGo7WqTFhwVH2yygU3Baoa38k4ERLNwT2WhYppJ5KRlAqTFyZoregMcH3nANcYY1NdQkdyRhmFMTcSocILSSWtq2oBDWjaBjU61OWWCXhzdcFh3HmgLllSQ+0xR70OvaHCvmFljnfbo5OOTWh49mSzRVkGHjkaA+LkymbOlw2rrodqAhtp3qZfDMM7RsSE61rm9HDdmOKJkWv6U6cs+HXm1HVLh+iKyy47W34US/QVLXYHsOvwT6cbQm6TiKdla0T+yJKI5vNJpTHDADFO5ehMagpPSNza+kaebgQM8NxUvGtwNhtfdeb5IAAF403VUVAsJ8zHi3DzQ41I/pBrvulPbNgvZNsgxW4w2OuGmDgQSHDfmOxZ54YNcM+T7SMe0o5Ffs5A/O4A91Krtn+kiOp9nY7+an/qpSfgG9iMNi5YUk4zFR0OOIBIGGOeKjWOul3y3/aVkIZhjnSTv+ncce7BSspbsBjheL4RIpciw3QyeDiLp70+gS78wXXCatDiLzRuIz7VFW/LxIjmMINwAl2oUpjjtWFmNq5vW1K0ijxSYj3sIEWKXB2bbrRRovDCuOSokZ9SStDnrTvyxhFhqIkN5dhShBBAGY1KgWhBuRXs91xHZXBdnFZ1HLy4Za8r9II7ERHC1Yw4hJ7CTGGnsFAXXkxHr4p2Qx5q6WmeaVT+TAesjn8rR4lWy1DzSoyOJnRb+Hb2+am2KF0W/h29qm2Kp0kZBdogmHnlsB/uO7kqyUi/hu7lrzbIZ7qOLMZsRobZPCko34ZVe0lgPZ0mkLfWWczYs+5UpFrYJdrqPNPQZxZNmxIg5jaqZgWFHH3PFW7k5k2mGCQr5/h7NgQIp9jwnMl23hzhCLe55p4JWzWFrWxgCSwkPAFXGG4UdQayCGOpruka1Y5mToRd1eO1NZelXUFMVjfVdG94wrB9HGbzXNc062mtD8DuKi5mSc11PohO5mz4LjfLAHa3tJY/+ppBKip2XP3Y8cAbXh397SotjTDGl4cvArV7ASmekFtiFCLIQAc6oaB/yPj4hQ89CeM5iKf8Atj+1gUjo1o+19Ir8gc3ElzyNpP3QiWHljU5ofYxgSvOHPfz37iQKN7AAO9MNMZf0Zl5sD2Tw2J/tvNKngf7lZ3TVId3fmjTco2JAdDcKhzSO8LLky1dtMMd46QsxJsePiEeybPuOr4qLiCNKBrMIsOlGhxuxGAfdv0Ie0aq0OqqkZC2Rm6DGHBgf/Y4rP/lXqrFKwzQDcoPSKdDYgZru1/lFXO8Gkdqk4NtMpzYMyeECIPFwAVatGSjPe+O6E5l6gPpHMv3QebDZDYSGgmhLi4k0pQVKmT3ulbv1DK05JrJaFeoDEdeiHY1gx7Fk0/GvxHv95zj3k0Wm6eTJZK0ri1ohfzPN6J/xAHassK6fzTcuV+sv2ZamOH9AEdqKEYLqcULQ0+gJjDT2XQa/cl7fbnqhWS1DgVX+TBvq45/M3yU5ahwKzyOLHowP3dimmKI0a/h2cFMMVzpA64uoJhANmCV0RXVSgYEKKiKQ3YLPuVc+oPEea0FpWecq/sDxHmg3eTQ+qCvrlQ+TP2QV+KQhCOw3aqGhzsN73NYRVlARrFa59ynonRPBZ3Zca7aMdnvww4cWO/8ApZ5T60xy+LNHiYKDm5sCtVKTBVR0hcW4azX6AWHj5V145+M25Emb7sck4g2+6Gz0cOlBXHOgOOI7VWIEZjsHGnbmflVScp6PKhFMsR2rW8ekzkuSzWXbhiUDiK7cgrH/AIqQBcunbUkd1AVRYUvDNQ1xaTtFe6iWEq4AARCdVcviubPHddMtk6We2R6bnZUFAPEppYsfUcxgVFxpuJCHSqCaYp9ZMQPdfH8w3rLLH0rHP4u0o/BNrRj0LcK0qe4fqEaWOCpmkWnUGDFiwwxz3s5oyDS6lTjWuZ2alGGNyupCyyxx930qfKPO1itgNOEMXnb3v1ns81TKJ3PTLor3RHmrnkk/WxNqL08MfHGR5nLn55XIUI4XKI4Vog7E9gZJnDCeQckG0bkzHqIx/OPIKVtQ4FRvJuP3WIdsT4J/ahWWXaot2jo9QzgpZii7BHqGdUKUYtZ0zpRBcqggM+iaZwB99veE3fpzA/ECxmiCvRNgOn0uPvqm6c6VQ5hlxlTUjwVSCbTGaQ2uOieljZdt1wPYrI7lFZqa5ZdACmpGVqEqa8HT9pB5rlWbEtUxLShvp0g5vYWk/BNo8AAK16A6LUD5uIKEc1g2XszxpTvS+HO1hmXKs2rKX3Xip+ffiRsKbQGgrn6dWPtCWVo1BLi97a0FRrqSdez9VLTWjkucYT3MJzB54B3A/CifHAYKJtCZe3KtNyP8l+t+PGSnTbJIoQIZFMQC5pOVNeGtFiWLNOwg+iYCcL1911tBUYnHEHvTGXtE4VLhxCtlmzFW4nUssstOi4469KHbVjTofzntLRSt0FoJ3VJVl0OlCASeCnooDktKwg0ZUWOfJuaZzDV2NPzQhQnRHYBrSTwAqsDmYxiPc92b3Fx4uNfitD5TLfAaJZh5zqGJTU3U07z5BZw1dX5cNY+V+uP9We8vH+nCEWiVoi0XU5RKIwC7RGASOOsCdwsk2aE5h5INpnJ6KSbt8QpzaWtJaBikkN7yj2ksb2qLtYg9SzqhSTFHWP7FnVCkWLaMx0EEEB5RXArVD0GjnM+CdwuT+Ic3HuWiVLTaYzWkQ+Ts63FLt5OmawT2pU2bS6slnnmq5wOT6EPup8/Q2ExlTQBTRFTsuR9K68eg3HidQWt6Py4dKBvvXu+uHwVJEs2E0NbkFa9CJ4Ohuh62GvYVUnobVi2GkOIyOfaMwoVtoXDirvpjZpp6Vo6w2HbwKz2dhh2IXLlfG6rswnljuLHAnoZANcCnT3spqKzuJGiQ8Mad9U4l7ZcMCTRK4etxWOerqruyWhuOQUlClAKAKhwraocHEqYl9JchX9VhlhW8zi3tYBmoTSvSH7NBL2irnG6yuV4gmp3ABO5EvitvuBDdQ2qjcpkzzoUIag557cB8VlxYzLkmJ8uVx47VNjxnPcXvJc5xq4nMkrjUVqO1es8qjUQojBdoghKLtEaiFEjBqXbkkglRkkbVNCxSRZvJXLRSmiQpIwuBRLQzWF7aTpebKHqmcAn7Ezs0erbwCesW8ZOoLqCAgxCahzQhRJOhElUkoYjVyHEBOCIJbek48dsPAYu2ahxTM6mJlsMVd2DWeCrc9OOiG87IZDUFy0pmlXvNT5bgq7/iV4uaDvHxTkI7m5quZSNi2sYEdsT7uT97T9VTN72pGJwwTDYHvD21wII7CCs/0n0dMMmLBFWHFzRm3eNoUnoTbF5noHnnM6Ndbf0VkiBY8mEymmvHyXC7jIjLhw2hNn2Y3eFoVraNhxL4IocyzU7e3YVX3SuOIIORBzBG0Lzc/Pjunp4XDkm1eh2SPqo8lYtHrFaXCoFNe09qTjSxAqFP6OxAW8FnlyZWdrmEnxLzQDWhoWQ8oMrEbOOLhgWMLSMRdI+dVqFrTN1hOtxDWjeVF6XwR6VrSAbsJgPHFb/jnu5OX9V/8yMcCUarlO2HCfkKHcoKasN7MsQvRlcGkcF1GdDIzFEVUQLq4gkHQlNSTBR9SSmu6MiklC6qQnsxxTuwBSUhdUJrOZjiPNc17ar7Z45jeATxqayPQbwTpi6GI6C4ggIS8EV0VozIWaSGk83MuuwYWGt7jRreJ27lbpWWfQXnXjrOqu4bFciT+NOF2DcBt1ngmMZ1MU4pT9VFWjFoM/r6qq6HasaQWhiQoSz45LwSc8O/9aJ9a7KuJUcG3RXYQe5Z+XtevSYa8/QSr3khIuGP6owO5XKnQsGO6E9sRpxBr8wtQsefbHhh41jHistjtyVg0OtAsfcOTsuKzyy1VSbjQQ1IWhZDIwqea8ZOHk7aEvDdVO2LPkxmU9rwyuN9KVMyBYSx7aHwO8HYl7OlxDbirZOSbYraHP7rtYPyWf2xKTceMZVrDChinpIupzT7h3rz7+e71OnoY/olx/2PZFZ2dvj2EucDqfE1kbgmmkc5+/RQejzW8KNHzV/sSyocvCbDhgAAalkuk8ek9Hr7/eKALs4sfH1HHy5eVPpuVNLzVGOjJ9KWhdbQ4imG5Q8dxz24rWMSc3Da4YhV+ZhXSpmLEUfMmquJqPvIVScTA0QDlRFgUpXBINKVCSo2eyBSVhdQJlNdIcR5p/Z4pLwuoExmOm3rDzXN9ar/ACfRHBOWpvKdEcE4auiMRl1cQQFOlZNrBRoAAyAFAlXHDwRnuTOO84962S5Mxd6gZyPVPJp+pREwcfrtUZX0rGGcxAqoi02UB4KyMZXuUPakjermsMe2t6PocMOaMcaDwRXwaKuNnZmCcfWN2HPvUzZltsjG7dc14+6R5HJVdxE07HbSm1dk4xa8EcapePDOZzPhuTJwx+sEt7Ppq1jTQiQ2uGsY8dal4ZVE0ItCjvRE9Lo9b9VbrStNkuwufUnU0Zn5cUbPSQjTDWNL3uDWtFSTqColq239piXWkiHhQYc4ai7HjhwVS0n0jmJiJR5usaTdhtrTLAk/eKQs+ddn2k51JANMBTVVLw+l5L/KWm+BdIcSyoDmmpFDrGwqrcolmkRnRW5Gjq8QpeRb6e60a6nux+XgpW2JT00uQRzmtoexTjdVV9xm1nR7zaa0nGiEGhFPIpEwTBiUORyTyaIpxV31UouawUfFepGYGCi46qVNNZ04gpNjkec6ISMMqiOWFLMzHEJuxOYPSbxHmlTja5Yeph9UeSYRfaN6wUiz2bOqPJR59ozrBc31sv8ALdEcEu1IQMgl2rpYDIIIIChmbIwcOFMjwTeYmeOHkVGNnvukinxRhFBwrnkdo+a0t0UgR4v1uTd2OpGPYuiD9fXascq0xjsMU7EhNt1p7Dh8UnNQahZztdRDGtc67gn0KSazogY57+O5Vy1oTobxEbqzG7WrLZE22KwEHMK8kQaLCqN6iI8NWJkMitcfluCjrRl/0UTtVMbPmCx4IOIIIPBX6egtjwBGbm5vO4jPxCzZ2BV40PnLzHQScxVvGmI+tirOfSxqn2tLh7DEAo5rsQcxTDtzGKipM7/M05udB9Yq+21KAwa0AJYWu4tyy4FZ5KxXEmlKAgXnPLRXVgMSDQjuVz3EXto2hJq5nVO33W7SrnFhVBFMwVQ9BhEbFAJFADebdc0ghja4k0wJoaBaAyICs9NIx7SeBza62uPmo+XfebirrppZfNe5o1moVAs6LzqK+4X0aI3UoqaYrHMwtaiJ2ClKViCmeikISczjcCmsJaIOYadynTb1h5ppDT2zx61g/MPNTTjaz0G9UKPZ7VnFSETot4BMIPtmcVzfW1X6DkEsEhCyCWauqMBkEEEBiR18U9Z0BxHk5BBXmJ2ND+vBOW5nh8EEFhWsLw9S6PiggpNA270TwKaaFdA9Z3muoK70n6tcXP62JpOdHs+aCCzhq9MKf0M9szrLqC1vSE1bvsonXf8A2lZnZ/TZ/tO/8bkEFWHRZdr5ye9P+V3kxXWHmuoKKudIXST2cTtWOy/tT1kEEY9UXtPx8lFTmSCCnHs6r09kUwhLqC1ZHDE/sz2sPrDzQQSvSo2uL0RwCYy/tmcVxBc07bVfIWQSzUEF1RzuoIIID//Z"
                                                        alt="">
                                                </div>
                                                <div class="d-inline-flex h-100 flex-column align-content-between">
                                                    <p class="name"><?php echo e($review->name); ?></p>
                                                    <div class="stars">

                                                        <?php for($i = 0; $i < 5; $i++): ?>
                                                            <div
                                                                class="<?php echo e($i < $review->rating ? 'star-fill' : 'star-outline'); ?>">
                                                                <svg xmlns="http://www.w3.org/2000/svg" width="14px"
                                                                    height="14px" viewBox="0 0 24 24">
                                                                    <path fill="none" stroke="currentColor"
                                                                        stroke-linejoin="round" stroke-width="2"
                                                                        d="m12 2l2.939 5.955l6.572.955l-4.756 4.635l1.123 6.545L12 17l-5.878 3.09l1.123-6.545L2.489 8.91l6.572-.955z">
                                                                    </path>
                                                                </svg>
                                                            </div>
                                                        <?php endfor; ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <p class="review-text">
                                                <?php echo e($review->comment); ?>

                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="pagination-container">
                                    <?php echo e($reviews->paginate(5)->links()); ?>

                                </div>

                            </div>
                        </div>


                    </div>
                </div>

                <div class="col-12 col-lg-6 mt-5 mt-lg-0">
                    <div class="add-review-card">
                        <h3 class="section-title">Add A Review</h3>
                        <p class="section-description">Your Email Address Will Not Be Published.</p>

                        <div class="stars d-flex">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <div class="star" data-value="<?php echo e($i); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20px" height="20px"
                                        viewBox="0 0 24 24">
                                        <path fill="none" stroke="currentColor" stroke-linejoin="round"
                                            stroke-width="2"
                                            d="m12 2l2.939 5.955l6.572.955l-4.756 4.635l1.123 6.545L12 17l-5.878 3.09l1.123-6.545L2.489 8.91l6.572-.955z">
                                        </path>
                                    </svg>
                                </div>
                            <?php endfor; ?>
                        </div>

                        <form action="<?php echo e(route('review.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="10">
                            <input type="text" class="form-control" name="name"
                                value="<?php echo e(old('name', session('name'))); ?>" placeholder="Name">
                            <input type="email" class="form-control" name="email"
                                value="<?php echo e(old('email', session('email'))); ?>" placeholder="Email">
                            <input type="hidden" name="rating" id="rating-input" value="0">
                            <textarea class="form-control" name="comment" cols="30" placeholder="Comment"></textarea>

                            <div class="d-flex gap-3">
                                <input type="checkbox" class="form-check-input" id="save-my-details"
                                    name="save_details">
                                <label for="save-my-details">
                                    Save My Name and Email In This Browser For The Next Time I Comment.
                                </label>
                            </div>

                            <button type="submit" class="btn secondary-gradiant-btn">
                                <svg xmlns="http://www.w3.org/2000/svg" id="Outline" viewBox="0 0 24 24"
                                    width="22" height="22">
                                    <path fill="white"
                                        d="M23.119.882a2.966,2.966,0,0,0-2.8-.8l-16,3.37a4.995,4.995,0,0,0-2.853,8.481L3.184,13.65a1,1,0,0,1,.293.708v3.168a2.965,2.965,0,0,0,.3,1.285l-.008.007.026.026A3,3,0,0,0,5.157,20.2l.026.026.007-.008a2.965,2.965,0,0,0,1.285.3H9.643a1,1,0,0,1,.707.292l1.717,1.717A4.963,4.963,0,0,0,15.587,24a5.049,5.049,0,0,0,1.605-.264,4.933,4.933,0,0,0,3.344-3.986L23.911,3.715A2.975,2.975,0,0,0,23.119.882ZM4.6,12.238,2.881,10.521a2.94,2.94,0,0,1-.722-3.074,2.978,2.978,0,0,1,2.5-2.026L20.5,2.086,5.475,17.113V14.358A2.978,2.978,0,0,0,4.6,12.238Zm13.971,7.17a3,3,0,0,1-5.089,1.712L11.762,19.4a2.978,2.978,0,0,0-2.119-.878H6.888L21.915,3.5Z" />
                                </svg>
                                <span>Add Review</span>
                            </button>
                        </form>

                    </div>
                </div>

            </div>
        </div>
    </section>

    <section class="related-products-section">
        <div class="container">
            <div class="row mx-auto">
                <div class="col-12">
                    <h3 class="section-title">Related Product</h3>
                </div>
                <div class="col-12 product-container">
                    <?php for($i = 0; $i < 5; $i++): ?>
                        
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </section>

    <a href="" id="image-full-view" data-fancybox="gallery">
    </a>

    <?php echo $__env->make('frontend.layouts.offers-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.layouts.features-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide@1.2.0/dist/css/splide.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@1.2.0/dist/js/splide.min.js"></script>


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css"
        integrity="sha512-H9jrZiiopUdsLpg94A333EfumgUBpO9MdbxStdeITo+KEIMaNfHNvwyjjDJb+ERPaRS6DpyRlKbvPUasNItRyw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"
        integrity="sha512-uURl+ZXMBrF4AwGaWmEetzrd+J5/8NRkWAvJx5sbPSSuOb0bZLqf+tOzniObO00BjHa/dD7gub9oCGMLPQHtQA=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        'use strict';

        var primarySlider = new Splide('#primary_slider', {
            type: 'fade',
            heightRatio: 0.5,
            pagination: false,
            arrows: false,
            cover: false,
        });

        var thumbnailSlider = new Splide('#thumbnail_slider', {
            rewind: true,
            fixedWidth: 100,
            fixedHeight: 64,
            isNavigation: true,
            gap: 10,
            focus: 'center',
            pagination: false,
            cover: false,
            breakpoints: {
                '600': {
                    fixedWidth: 66,
                    fixedHeight: 40,
                }
            }
        }).mount();

        primarySlider.sync(thumbnailSlider).mount();

        function viewImage(element) {
            let image = $(element).find('img').attr('src');
            $('#image-full-view').attr('href', image);
            $('#image-full-view').trigger('click');
        }
    </script>

    <script>
        'use strict';

        const stars = document.querySelectorAll(".star");
        const ratingInput = document.getElementById("rating-input");

        stars.forEach((star, index) => {
            star.addEventListener("click", () => {
                const ratingValue = index + 1;
                ratingInput.value = ratingValue;

                stars.forEach((s, i) => {
                    if (i < ratingValue) {
                        s.classList.add("active");
                    } else {
                        s.classList.remove("active");
                    }
                });
            });
        });


        function changeAttributesValues(element) {
            var variationSelect = element.getAttribute('data-variation-id');

            var form = document.getElementById('variation-form');

            var formData = new FormData(form);
            formData.append('product_id', '<?php echo e($product->id); ?>');
            formData.append('variation_id', variationSelect);
            formData.append('value_id', element.value);

            fetch('<?php echo e(route('shop.product.options')); ?>', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    }
                })
                .then(response => response.json())
                .then(data => {

                    data.resultset.forEach(item => {
                        const selectElement = document.querySelector(
                            `select[data-variation-id="${item.variable}"]`
                        );

                        if (selectElement && (selectElement !== element)) {
                            const options = selectElement.options;

                            // disable all options
                            for (let i = 0; i < options.length; i++) {
                                options[i].disabled = false;
                            }

                            // enable selected options
                            data.resultset.forEach(innerItem => {
                                if (innerItem.variable === item.variable) {
                                    for (let i = 0; i < options.length; i++) {
                                        if (parseInt(options[i].value) === innerItem.value) {
                                            options[i].disabled = false;
                                            options[i].selected = true;

                                            var originalPrice = document.getElementById(
                                                'original-price').value;
                                            alert(originalPrice);

                                            if (originalPrice && originalPrice.value == 0) {

                                                changeAttributesValues([options[i]]);
                                            }


                                        } else {
                                            options[i].selected = false;
                                        }
                                    }
                                }
                            });
                        } else {
                            const options = element.options;
                            // enable all options
                            for (let i = 0; i < options.length; i++) {
                                options[i].disabled = false;
                            }
                        }

                        updatePrice(data.price);

                        var addToCartBtn = document.getElementById('detail-addtocart-btn');
                        addToCartBtn.setAttribute(
                            'data-variation-id', data.productVariationId);

                    });

                    if (data.stock > 0) {
                        let qty = document.getElementById('qty');
                        if (qty.value > data.stock) {
                            qty.value = data.stock;
                        }
                        qty.max = data.stock;
                        document.getElementById('qty').max = data.stock;
                        document.getElementById('availability').innerHTML = ' Availablility: In Stock';
                    } else if (data.stock == 0) {
                        let qty = document.getElementById('qty');
                        qty.value = 0;
                        qty.max = 0;
                        document.getElementById('qty').value = 0;
                        document.getElementById('availability').innerHTML = ' Availablility: Out of Stock';
                    }

                })
                .catch(error => console.error('Error:', error));
        }

        function chnageQty(action) {
            var qtyInput = document.getElementById('qty');
            var currentQty = parseInt(qtyInput.value);

            if (action === '-') {
                if (currentQty > 1) {
                    currentQty--;
                }
            } else if (action === '+') {
                currentQty++;
            }

            qtyInput.value = currentQty;
            updatePrice(null, currentQty);
        }

        function updatePrice(price, qty = 1) {
            var originalPrice = document.getElementById('original-price');
            var productPrice = document.getElementById('product-price');

            if (price > 0) {
                originalPrice.value = price;
            }

            const unitPrice = originalPrice.value;
            const totalPrice = unitPrice * qty;

            var formatPrice = new Intl.NumberFormat('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
            }).format(totalPrice);

            if (productPrice) {
                productPrice.innerHTML = 'RS ' + formatPrice + '/=';
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/frontend/pages/shop/detail.blade.php ENDPATH**/ ?>