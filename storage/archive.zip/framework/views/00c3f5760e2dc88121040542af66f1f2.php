<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="<?php echo e($site_favicon); ?>">

    <meta name="description" content="<?php echo e($meta_description); ?>">

    <meta name="robots" content="noindex, nofollow">
    <meta name="author" content="<?php echo e($site_name); ?>">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="stylesheet"
        href="<?php echo e(asset('assets/backend/css/app.css')); ?>?v=<?php echo e(filemtime(public_path('assets/backend/css/app.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/backend/vendors/bootstrap/bootstrap.min.css')); ?>">

    <!-- Bootstrap Tags Input CSS -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.css">

    <!-- Slick Carousel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css" />

    <!-- Icons -->
    <link rel='stylesheet'
        href='<?php echo e(asset('assets/global/icons/uicons-regular-rounded/css/uicons-regular-rounded.css')); ?>'>
    <link rel='stylesheet' href='<?php echo e(asset('assets/global/icons/uicons-solid-rounded/css/uicons-solid-rounded.css')); ?>'>
    <link rel='stylesheet' href='<?php echo e(asset('assets/global/icons/uicons-bold-rounded/css/uicons-bold-rounded.css')); ?>'>
    <link rel='stylesheet' href='<?php echo e(asset('assets/global/icons/uicons-bold-straight/css/uicons-bold-straight.css')); ?>'>
    <link rel='stylesheet' href='<?php echo e(asset('assets/global/icons/uicons-thin-rounded/css/uicons-thin-rounded.css')); ?>'>

    <!-- Toastify -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastify-js/1.6.1/toastify.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastify-js/1.6.1/toastify.min.js"></script>


    <!-- Sweet Alert 2 -->
    <link href="https://cdn.jsdelivr.net/npm/@sweetalert2/theme-dark@4/dark.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>

    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <!-- Tiny MCE -->
    <script src="<?php echo e(asset('assets/global/tinymce/tinymce.min.js')); ?>"></script>

    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-- Axios -->
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/nprogress/nprogress.css" />
    <script src="https://cdn.jsdelivr.net/npm/nprogress/nprogress.js"></script>

    <!-- Include Choices.js CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>


    <!-- Include SweetAlert CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <!-- Include SweetAlert JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    

</head>

<body>
    <div id="app">
        <?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main-content app-content">
            <div class="container-xxl px-1">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <?php echo $__env->make('backend.layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tagsinput/0.8.0/bootstrap-tagsinput.min.js"></script>
    <script
        src="<?php echo e(asset('assets/backend/js/fileChooser.js')); ?>?v=<?php echo e(filemtime(public_path('assets/backend/js/app.js'))); ?>">
    </script>
    <script src="<?php echo e(asset('assets/backend/js/app.js')); ?>?v=<?php echo e(filemtime(public_path('assets/backend/js/app.js'))); ?>">
    </script>
    <?php if(session('error')): ?>
        <script type="text/javascript">
            showToast("<?php echo e(session('error')); ?>");
        </script>
    <?php endif; ?>


    <?php if(session('success')): ?>
        <script type="text/javascript">
            showToast("<?php echo e(session('success')); ?>");
        </script>
    <?php endif; ?>


</body>

</html>
<?php /**PATH /home/capturez-digimax/htdocs/digimax.capturez.net/resources/views/backend/app.blade.php ENDPATH**/ ?>